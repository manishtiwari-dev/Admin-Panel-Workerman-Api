import styled from "@doar/shared/styled";

export const StyledWrap = styled.div`
    &:not(:last-of-type) {
        margin-bottom: 50px;
    }
`;
