export const loginUrl = "http://127.0.0.1:8000/api/login/";
export const userUrl = "http://127.0.0.1:8000/api/users/";
