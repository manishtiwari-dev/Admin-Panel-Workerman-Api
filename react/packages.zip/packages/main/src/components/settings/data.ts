import { TTheme } from "@doar/shared/types";

export const SkinModes: TTheme[] = ["classic", "light", "cool", "dark"];
