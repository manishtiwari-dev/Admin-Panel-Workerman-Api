import styled from "@doar/shared/styled";

export const StyledWrap = styled.div`
    padding-left: 20px;
    padding-right: 20px;
    padding-top: 10px;
    padding-bottom: 10px;
`;
