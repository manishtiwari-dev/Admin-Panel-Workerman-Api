import styled from "@doar/shared/styled";

export const StyledWrap = styled.div`
    padding: 10px;
`;
