import styled from "@doar/shared/styled";

export const StyledWrap = styled.div`
    padding-top: 20px;
    padding-bottom: 10px;
    padding-left: 10px;
    padding-right: 10px;
`;
