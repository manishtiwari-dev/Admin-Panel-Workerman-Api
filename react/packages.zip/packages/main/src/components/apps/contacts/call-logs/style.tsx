import styled from "@doar/shared/styled";

export const StyledBar = styled.div`
    margin-bottom: 25px;
    align-items: center;
    justify-content: space-between;
    display: flex;
`;
