import styled from "@doar/shared/styled";

export const StyledWrap = styled.div`
    font-size: 13px;
`;
