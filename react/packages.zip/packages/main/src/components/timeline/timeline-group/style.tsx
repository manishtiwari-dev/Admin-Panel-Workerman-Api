import styled from "@doar/shared/styled";

export const StyledGroup = styled.div`
    font-size: 13px;
`;
