import { FC } from "react";

const Title: FC = ({ children }) => {
    return <div>{children}</div>;
};

export default Title;
