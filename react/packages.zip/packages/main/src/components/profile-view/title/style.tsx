import styled from "@doar/shared/styled";

export const StyledTitle = styled.h6``;
