export interface LoginInfo {
    email: string;
    password: string;
}